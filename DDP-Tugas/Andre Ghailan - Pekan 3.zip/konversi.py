print("===== Konversi Celcius - Fahrenheit =====") 
celcius = float(input("Masukkan suhu dalam Celcius: ")) 
fahrenheit = (celcius * 9/5) + 32
print("Hasil Konversi = " , fahrenheit, "Fahrenheit")
