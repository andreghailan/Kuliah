nama = "Agung Kurniawan"
nim = "0112027378"
kelas = "SI-02" 
no_telp = "089655267523"
alamat = "Jl. Nusantara  NO.31 Depok"

print("===== Profil Mahasiswa =====")
print("Nama:", nama)
print("NIM:", nim)
print("Kelas:", kelas)
print("No. Telp:", no_telp)
print("Alamat:", alamat)