print("===== Menghitung Berat Badan Ideal =====")
tb = float (input("Masukan tinggi badan (cm): "))
ideal = (tb - 100) - (tb - 100) * 10/100
print("Berat badan ideal anda adalah", ideal, "kg")