nama = "Andre Ghailan Pratama"
nim = "0110125047"
kelas = "SI-02" 
no_telp = "089613351243"
alamat = "Jl. Bakti RT.001/RW.012 Kel. Kebon Bawanng Kec. Tanjung Priok"

print("===== Profil Pribadi =====")
print("Nama:", nama)
print("NIM:", nim)
print("Kelas:", kelas)
print("No. Telp:", no_telp)
print("Alamat:", alamat)
